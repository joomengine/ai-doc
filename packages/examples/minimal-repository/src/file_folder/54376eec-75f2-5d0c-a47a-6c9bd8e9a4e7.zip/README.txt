Original CC0 folder-transport fixture.
